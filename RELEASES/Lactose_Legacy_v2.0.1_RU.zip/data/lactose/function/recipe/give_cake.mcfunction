advancement revoke @s only lactose:recipe/craft_cake
recipe take @s lactose:crafting/lactose_free_cake
clear @s minecraft:knowledge_book 1
give @s minecraft:cake{lactose_free_cake:1b,display:{Name:'{"text":"Безлактозный торт","color":"aqua","italic":false}',Lore:['{"text":"Испечён с безлактозным молоком.","color":"gray","italic":false}','{"text":"Кусочки не вызывают реакцию на лактозу.","color":"dark_aqua","italic":false}']}} 1
recipe give @s lactose:crafting/lactose_free_cake
