scoreboard players set $mode lactose.config 3
scoreboard players set $challenge lactose.config 0
scoreboard players set $decay lactose.config 300
tellraw @s [{"text":"[Lactose] ","color":"aqua"},{"text":"Включён острый режим. Ошибка с молоком станет заметнее. Испытание выключено.","color":"gray"}]
