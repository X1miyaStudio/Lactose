scoreboard players set $mode lactose.config 1
scoreboard players set $challenge lactose.config 0
scoreboard players set $decay lactose.config 300
tellraw @s [{"text":"[Lactose] ","color":"aqua"},{"text":"Включён мягкий режим. Реакции короче, испытание выключено.","color":"gray"}]
