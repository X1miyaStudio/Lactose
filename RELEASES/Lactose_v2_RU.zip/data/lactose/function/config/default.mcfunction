scoreboard players set $mode lactose.config 2
scoreboard players set $challenge lactose.config 0
scoreboard players set $decay lactose.config 240
tellraw @s [{"text":"[Lactose] ","color":"aqua"},{"text":"Включён обычный сбалансированный режим. Испытание выключено.","color":"gray"}]
