scoreboard players set $challenge lactose.config 0
tellraw @s [{"text":"[Lactose] ","color":"aqua"},{"text":"Режим испытания выключен.","color":"gray"}]
