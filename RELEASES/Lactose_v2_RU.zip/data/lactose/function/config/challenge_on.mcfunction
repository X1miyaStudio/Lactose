scoreboard players set $challenge lactose.config 1
tellraw @s [{"text":"[Lactose] ","color":"aqua"},{"text":"Режим испытания включён. Молоко быстрее усиливает реакцию.","color":"gray"}]
