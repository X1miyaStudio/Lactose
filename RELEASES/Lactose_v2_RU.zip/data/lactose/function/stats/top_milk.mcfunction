scoreboard objectives setdisplay sidebar lactose.total
tellraw @s [{"text":"[Lactose] ","color":"aqua"},{"text":"Боковая панель показывает выпитые вёдра молока. Чтобы скрыть её: /function lactose:stats/clear_sidebar.","color":"gray"}]
