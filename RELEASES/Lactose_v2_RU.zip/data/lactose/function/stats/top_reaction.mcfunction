scoreboard objectives setdisplay sidebar lactose.best
tellraw @s [{"text":"[Lactose] ","color":"aqua"},{"text":"Боковая панель показывает максимальную реакцию игроков. Чтобы скрыть её: /function lactose:stats/clear_sidebar.","color":"gray"}]
