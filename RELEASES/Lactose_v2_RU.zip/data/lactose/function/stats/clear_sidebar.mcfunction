scoreboard objectives setdisplay sidebar
tellraw @s [{"text":"[Lactose] ","color":"aqua"},{"text":"Боковая панель очищена.","color":"gray"}]
