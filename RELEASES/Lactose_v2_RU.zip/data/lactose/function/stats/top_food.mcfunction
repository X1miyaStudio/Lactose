scoreboard objectives setdisplay sidebar lactose.food
tellraw @s [{"text":"[Lactose] ","color":"aqua"},{"text":"Боковая панель показывает порции молочной еды. Чтобы скрыть её: /function lactose:stats/clear_sidebar.","color":"gray"}]
